import UIKit

let url = URL(string: "https://threatview.io/Downloads/IP-High-Confidence-Feed.txt")!

let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
    guard let data = data else { return }
    //print(String(data: data, encoding: .utf8)!)
    let ipList = String(data: data, encoding: .utf8)!
    let array = ipList.components(separatedBy: "\n")
    //print(array)
    let filteredArray = array.filter({ $0 != ""})
    //print(filteredArray)
    addItemToList(items: filteredArray)
}

func addItemToList(items: [String]) {
    print("Running....")
    print("Completed Rules Array")
    print("Creating Block List")
    
    let blocklist = LittleSnitchBlockList(name: "Threatview IP Blocklist", description: "Malicious IP Blocklist for known Bad IP addresses", rules: items)
    
    do {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .sortedKeys
        encoder.outputFormatting = .prettyPrinted
        let jsonData = try encoder.encode(blocklist)
        let jsonString = String(data: jsonData, encoding: .utf8)!
        print(jsonString)
        
        // and decode it back
        let decodedSentences = try JSONDecoder().decode([LittleSnitchBlockList].self, from: jsonData)
        print(decodedSentences)
    } catch { print(error) }
}



task.resume()


struct LittleSnitchBlockList: Codable {
    var name: String
    var description: String
    var rules: [String]
    
    enum CodingKeys: String, CodingKey {
        case name = "name"
        case description = "description"
        case rules = "denied-remote-addresses"
    }
}




